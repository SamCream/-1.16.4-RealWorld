package com.samcream.realworld.realworld.lists;

import net.minecraft.item.Item;

public class ItemList {
    public static Item MagnesiumDust;
//    public static Item ProfessionalFiringDevice;
    public static Item MagnesiteItem;
    public static Item MagnesiumCarbonate;
    public static Item MagnesiumChloride;
    public static Item MagnesiumBicarbonate;
    public static Item MagnesiumChlorideHexahydrate;
}
